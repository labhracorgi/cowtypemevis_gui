
import numpy
import re
import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button, RadioButtons
import threading
import time
import scipy.ndimage


#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
# 

#Variables for communication w/ extra thread
line_start_vc = np.array((0,0,0))#x,y,z
line_end_vc    = np.array((0,0,0))
line_length   = 0
plot_updater_update = False

def update_line():
  #Fix end position
  line_end_wc = tuple(
                    np.array( ctx.module('XMarkerListContainer').field('posXYZ').value ) 
                    + 
                    np.array( ctx.module('XMarkerListContainer').field('vecXYZ').value )
                    )
  ctx.module('EndPosition').field('worldX').value = line_end_wc[0]
  ctx.module('EndPosition').field('worldY').value = line_end_wc[1]
  ctx.module('EndPosition').field('worldZ').value = line_end_wc[2]
  #Set the value's we want
  global line_start_vc,line_end_vc,line_length,plot_updater_update
  line_start_vc = np.array( ctx.module('StartPosition').field('voxelPos').value )
  line_end_vc   = np.array( ctx.module('EndPosition').field('voxelPos').value )
  line_direction_wc = np.array( ctx.module('XMarkerListContainer').field('vecXYZ').value )
  line_length = np.linalg.norm(line_direction_wc)
  #Talk
  #print "Updated line: {0} - {1} ({2} mm)".format(line_start_vc,line_end_vc,line_length)
  #Update
  plot_updater_update = True
  plot_update()  

#plot_updater_thread = None
#plot_updater_stop = False
#def initialisation():
#  global plot_updater_thread,plot_updater_stop
#  print "init"
#  plot_updater_stop = False
#  plot_updater_thread = threading.Thread(target=plot_updater)
#  plot_updater_thread.start()
#def finalisation():
#  global plot_updater_thread,plot_updater_stop
#  plot_updater_stop = True


#def plot_updater():
#  '''
#  Run this function in a separate thread.
#  Communication is done via the global variables.
#
#  Creates (if necessary) the plot with the intensity along the line.
#  Ensures there is a timer that automatically updates
#  '''
#  global plot_updater_thread,plot_updater_stop
#  print "Start of plot_updater"
#  while not plot_updater_stop:
#    print "In while"
#    if plot_updater_update:
#      plot_updater_update = False 
#      print "Update plot"
#      plot_update()
#    else:
#      #plot is already shown or there is no need to show it
#      print "Sleep"
#      time.sleep(1)
#  print "End of plot_updater"      


def plot_update():
  '''
  Update the plot
  '''
  global line_start_vc,line_end_vc,line_length,plot_updater_update
  intensity_profile_interpolation_order = ctx.field("intensity_profile_interpolation_order").value
  num = ctx.field("intensity_profile_num_points").value
  ##Get the values
  lengths = np.linspace(start=0,stop=line_length,num=num)
  # get the input image field's direct access to the image (which is a MLPagedImageWrapper, see MeVisLab Scripting Reference)
  # NB, coordinates were in MVL convention, Python uses itk convention. Therefore - (0.5,0.5,0.5)
  image = ctx.module("ImageBypass").field("output0").image()
  offset3D = np.floor(np.minimum(line_start_vc,line_end_vc) - (0.5,0.5,0.5)).astype(np.int)
  extent3D = np.ceil(np.maximum(line_start_vc,line_end_vc) - (0.5,0.5,0.5)).astype(np.int) - offset3D + np.ones((3))  #TODO: are these ones necessary?
  offset,extent = tuple(offset3D)+(0,0,0), extent3D
  #print "offet,extent: {0},{1} | {2},{3}".format(offset3D,extent3D, offset,extent)
  tile   = image.getTile( offset,extent)
  if tile == None:
    MLAB.logError("getTile failed: " + str(offset) + " " + str(extent))
  #print "Got tile of size {0}".format(tile.shape)
  #print tile
  # Extract the values along the line, using cubic interpolation
  x0,y0,z0 = ( line_start_vc - offset3D - (0.5,0.5,0.5))
  x1,y1,z1 = ( line_end_vc - offset3D - (0.5,0.5,0.5))
  x, y, z = np.linspace(x0, x1, num), np.linspace(y0, y1, num), np.linspace(z0, z1, num)
  intensities = scipy.ndimage.map_coordinates(tile.astype(np.float32), np.vstack((z,y,x)), order=intensity_profile_interpolation_order)
  #print intensities
  
  ##Plot 
  ctx.module('Curve').field('curveTable').value = "# Intensity\n"+"\n".join(["{0} {1}".format(length,intensity) for length,intensity in zip(lengths,intensities)])
  
  ##Determine length above threshold
  threshold = ctx.field("threshold").value
  points_above_threshold = np.array( [intensity>threshold for intensity in intensities] )
  point_lengths_above_threshold = points_above_threshold * (line_length/(num-1))
  point_lengths_above_threshold[[0,-1]] = point_lengths_above_threshold[[0,-1]]/2 #first and last point only are half the length
  point_lengths_above_threshold[point_lengths_above_threshold==0] = -float('inf') #to make the mssl work, we must set the point below threshold to a very low value
  index0,index1,length_above_threshold = mssl(point_lengths_above_threshold)
  ctx.field('length').value = line_length
  ctx.field("length_above_threshold").value = length_above_threshold
  
  ##Plot the threshold and the selected part
  ctx.module('CurveThreshold').field('curveTable').value = "# Threshold\n"+"\n".join(["{0} {1}".format(length,threshold) for i,length in enumerate(lengths) if i>=index0 and i<index1])
  
  ##Set y limits of plot 
  ctx.field('SoDiagram2D.minY').value = min(threshold, np.min(intensities))
  ctx.field('SoDiagram2D.maxY').value = max(threshold, np.max(intensities))*1.25
  
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
# 

def mssl(l):
    '''
    Maximum sum sublist.
    This returns a tuple (a, b, c) such that sum(l[a:b]) == c and c is maximal:
    '''
    best = cur = 0
    curi = starti = besti = 0
    for ind, i in enumerate(l):
        if cur+i > 0:
            cur += i
        else: # reset start position
            cur, curi = 0, ind+1

        if cur > best:
            starti, besti, best = curi, ind+1, cur
    return starti, besti, best

